package training.bosch.aa.daoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;

import training.bosch.aa.util.ResourceManager;


import training.bosch.aa.dao.QueryDetailsDAO;
import training.bosch.aa.domain.PersonalInfo;
import training.bosch.aa.domain.QueryDetails;

public class QueryDetailsDAOImpl implements QueryDetailsDAO {

	public boolean delete(QueryDetails qd) {
		// TODO Auto-generated method stub
		return false;
	}

	public PersonalInfo findByPresentorName(String pName) {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean insert(QueryDetails qd, PersonalInfo pi)
	{	int flag=1;
		Connection conn = ResourceManager.obtainConnection();
		try {
			
			if(flag==1)
			{	
				PreparedStatement pstat1= conn.prepareStatement(QUERY_SEQ);
				int rowAffect= pstat1.executeUpdate();
				flag++;
			}
			
		
			PreparedStatement pstat = conn.prepareStatement(INSERTQUERY_QUERY);
			pstat.setString(1, qd.getQuery());
			pstat.setString(2, qd.getAnswer());
			pstat.setString(3, qd.getStatus());
			pstat.setString(4, pi.getfName());
			int rowsAffect = pstat.executeUpdate();
			if (rowsAffect > 0) {
				ResourceManager.disConnect();
				return true;
			} else {
				ResourceManager.disConnect();
				return false;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ResourceManager.disConnect();

		
		return false;
		
	}

	public ArrayList<QueryDetails> read() {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean update(QueryDetails qd) {
		// TODO Auto-generated method stub
		return false;
	}

}
